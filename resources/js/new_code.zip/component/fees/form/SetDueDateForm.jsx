import React,{Component} from "react"
import api from "../../api"
import Swal from "sweetalert2";
import { connect } from "react-redux";
import GetInstallmentYear from "./GetInstallmentYear"
import CardComponent from "../../utils/CardComponent"

export default class SetDueDateForm extends Component{
    constructor(props){
        super(props)
        this.state = {
            last_due_date:""
        }
        this.getDueDate = this.getDueDate.bind(this)
    }
    getDueDate(data){
        return api.admin.fee.get_due_date(data).then(data => {
            console.log(data.last_due_date)
            this.setState({
                last_due_date:data.last_due_date
            })
        })
    }
    render(){
        const {last_due_date} = this.state
        return(
           <div>
                <GetInstallmentYear submit={this.getDueDate} />
                { last_due_date &&  
                    <CardComponent title="Update Due Date">
                    {last_due_date == null ? <input type="date" className="form-control"/>
                    
                    : <input type="date" name="last_" onChange={e => this.onChange(e)} className="form-control" value={last_due_date}/>}
                    </CardComponent>
                }
           </div>
        )
    }
}
