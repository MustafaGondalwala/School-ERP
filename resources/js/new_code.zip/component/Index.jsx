import React, { Component } from "react";
import ReactDOM from "react-dom";
import { BrowserRouter, Route } from "react-router-dom";
import LoginPage from "./authentication/LoginPage"

import GuestRoute from "./routes/GuestRoute"
import AdminDashboardRoutes from "./routes/AdminDashboardRoutes"
import Admin, {AdminDashboardHome} from "./dashboard/Admin"

import { createStore, applyMiddleware } from "redux";
import { composeWithDevTools } from "redux-devtools-extension";
import { Provider } from "react-redux";
import thunk from "redux-thunk";
import rootReducer from "./rootReducer";

import { userLoggedIn } from "./actions/login";
import setAuthorizationHeader from "./utils/setAuthorizationHeader";

const store = createStore(
  rootReducer,
  composeWithDevTools(applyMiddleware(thunk))
);


import StudentAdminHomePage from "./student/pages/StudentAdminHomePage"
import StudentNewRegisterStudent from "./student/pages/NewRegisterStudent"
import StudentViewStudent from "./student/pages/StudentViewStudent"
import StudentProfileUpdate from "./student/pages/StudentProfileUpdate"


import TeacherAdminHomePage from "./teacher/pages/TeacherAdminHomePage"
import TeacherAddTeacher from "./teacher/pages/TeacherAddTeacher"
import TeacherViewTeacher from "./teacher/pages/TeacherViewTeacher"



import FeesAdminHomePage from "./fees/pages/FeesAdminHomePage"
import FeeInstallments from "./fees/pages/FeeInstallments"
import FeeSetDueDate from "./fees/pages/FeeSetDueDate"
if (localStorage.token) {
  var payload = JSON.parse(localStorage.userAccount);
  setAuthorizationHeader(localStorage.token,payload.user_type,payload.school_id);
  store.dispatch(userLoggedIn(payload));
}

class Index extends Component {
    render() {
      return (
        <BrowserRouter>
          <Provider store={store}>
            <GuestRoute path="/login" exact component={LoginPage} />
            <GuestRoute path="/" exact component={LoginPage} />
            <AdminDashboardRoutes exact path="/admin/dashboard" component={AdminDashboardHome} />
            <AdminDashboardRoutes exact path="/admin/student" component={StudentAdminHomePage} />
            <AdminDashboardRoutes exact path="/admin/student/add-new-student" component={StudentNewRegisterStudent} />
            <AdminDashboardRoutes exact path="/admin/student/view-student" component={StudentViewStudent} />
            <AdminDashboardRoutes exact path="/admin/student/update-student-info" component={StudentProfileUpdate}/>


            <AdminDashboardRoutes exact path="/admin/teacher" component={TeacherAdminHomePage} />
            <AdminDashboardRoutes exact path="/admin/teacher/add-new-teacher" component={TeacherAddTeacher} />
            <AdminDashboardRoutes exact path="/admin/teacher/view-teacher" component={TeacherViewTeacher} />

            <AdminDashboardRoutes exact path="/admin/fees/" component={FeesAdminHomePage} />
            <AdminDashboardRoutes exact path="/admin/fees/set-installments" component={FeeInstallments} />
            <AdminDashboardRoutes exact path="/admin/fees/set-due-dates" component={FeeSetDueDate} />
            
          </Provider>
        </BrowserRouter>
      )
    }
}

ReactDOM.render(<Index />, document.getElementById("app"));
