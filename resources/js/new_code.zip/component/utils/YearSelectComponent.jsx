import React,{Component} from "react"
import {setYearDispatch} from "../actions/fee"
import { connect } from "react-redux";
import InlineError from "./InlineError"

class YearSelectComponent extends Component{
    componentDidMount(){
        if(Object.keys(this.props.years).length == 0){
            this.props.setYearDispatch();
        }
    }
    render(){
        const {label,years,onChange,name,colType,errors} = this.props
        return(
            <div clasName={colType}>
                <div className="form-group">
                    <label className="form-control-label">{label}</label>
                    <select name={name} onChange={onChange} className="form-control">
                        <option value="">-- Select --</option>
                        {Object.keys(years).length > 0 && years.map(item => {
                            return <option value={item.id}>{item.year}</option>
                        })}
                    </select>
                    {errors[name] && <InlineError text={errors[name]}/>}
                </div>
            </div>
        )
    }
}


function mapStateToProps(state) {
    return {
      years:state.year
    };
}

export default connect(mapStateToProps,{setYearDispatch})(YearSelectComponent);