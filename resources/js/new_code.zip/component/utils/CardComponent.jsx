import React,{Component} from "react"
import {Link} from "react-router-dom"
const CardComponent = ({title,back_link,children}) => {
    return(
        <div className="card">
            <div className="card-header">
                <h3 className="card-title mb-3">
                    {title}
                    {back_link && 
                    <Link
                      to={back_link}
                      class="btn btn-neutral float-right"
                      type="submit"
                    >
                      Back
                    </Link>
                    }
                </h3>
            </div>
            <div className="card-body">
                {children}
            </div>
        </div>
    )
}

export default CardComponent