import { combineReducers } from "redux";

import user from "./reducers/user";
import installments from "./reducers/setInstallments"
import year from "./reducers/setYear"

export default combineReducers({
    user,
    installments,
    year
  });