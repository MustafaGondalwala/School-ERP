export default {
    admin: {
        get_subjects: () => axios("/api/v1/admin/subject").then(response => response.data.success),
        get_distinct_class: () => axios("/api/v1/admin/class/distinct").then(response=> response.data.success),
        add_teacher: data => axios.post("/api/v1/admin/teacher",data,{headers:{'Content-Type': 'multipart/form-data'}}).then(response => response.data.success),
        view_all_teacher: () => axios("/api/v1/admin/teacher").then(response => response.data.success),
        view_particular_teacher: teacher_id => axios("/api/v1/admin/teacher/"+teacher_id).then(response => response.data.success),
    	student:{
    		view_all_student: () => axios("/api/v1/admin/student").then(response => response.data.success),
        },
        fee:{
            get_installments: () => axios("/api/v1/admin/fee/installments").then(response => response.data.success),
            update_installments: total_installments => axios.put("/api/v1/admin/fee/installments",{total_installments}).then(response => response.data.success),
            get_due_date: data => axios.post("/api/v1/admin/fee/due_date",data).then(response => response.data.success),
        },
        get_years: () => axios("/api/v1/year").then(response => response.data.success)
    }
}