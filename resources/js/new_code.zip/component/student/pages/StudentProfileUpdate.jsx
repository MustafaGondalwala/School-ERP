import React,{Component} from "react"
import AdminHeader from "../header/AdminHeader"
export default class StudentProfileUpdate extends Component{
	render(){
		return(
			<div>
				<AdminHeader mainHeader="Student" header="Profile Update"/>
			</div>
		)
	}
}