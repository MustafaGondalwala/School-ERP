import React,{Component} from "react"


const InlineError = ({ text }) => (
    <span style={{ color: "#ae5856" }}>{text}</span>
  );

export default InlineError;
